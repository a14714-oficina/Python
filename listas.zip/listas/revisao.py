alunos = []
#Inserir um aluno
alunos.append("Antonio")
alunos.append("Bernardo")
alunos.extend(["David","Filipe","Guilherme"])
alunos.extend(["Carlos","Leandro","Salvador","Tiago"])
alunos.insert(3,"Afonso")
alunos.remove("Bernardo")
alunos.pop(7)
numero_aluno_escolhido = alunos.index("Afonso")
print(f"Total de alunos: {len(alunos)}")
print(f"lista de alunos: {alunos}")
print(f"Aluno escolhido: {numero_aluno_escolhido}")

