numeros = [1,2,3,4,5,6,7,8,9,10]
 #1.
pares = [i for i in range(1, 11) if i % 2 == 0]
print(pares)

#2.
quadrados = [i * i for i in range(1, 11)]
print(quadrados)

#3.
palavras = ['Programação', 'JavaScript', 'Python']
tamanhos = [len(palavra) for palavra in palavras]
print(tamanhos)

#4.
maiores_que_5 = [num for num in numeros if num > 5]
print(maiores_que_5)

#5.
nome = 'MarcelO ViEiRa amorIM'
maiusculas = [letra for letra in nome if letra.isupper()]
print(maiusculas)

#6.
numeros = [2, 3, 4, 6, 7, 9, 10]
nova_lista = [num * 2 if num % 3 == 0 else num for num in numeros]
print(nova_lista)

#7.
nomes = ['Ana', 'Daniel', 'Leandro', 'Carlos', 'Maria', 'André']
nomes_com_a = [nome.upper() for nome in nomes if nome.lower().startswith('a')]
print(nomes_com_a)

#8.
frutas = ['maçã','morango','banana']
comprimento = [len(fruta) if len(fruta)>5 else 0 for fruta in frutas]
print(comprimento)