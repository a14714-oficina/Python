lista = [1,2,3,"Carlos",45.23,True]
aluno = ["Filipe",18,72,1.74,"Olhos Azuis"]
# print(type(lista))
# print(aluno)
# print(f"Nome do aluno: {aluno[0]}")
nums = [10,13,7,11,23,16]
soma = sum(nums)
maior_valor = max(nums)
menor_valor = min(nums)
total_de_elementos_da_lista = len(nums) #6
# Inserir um novo valor no final da lista
nums.append(4)
# Inserir vários valores no final da lista
nums.extend([91,32,11])
# Inserir um novo valor em uma posição especifica da lista
nums.insert(2,108)
print(nums)
# Remover o ultimo elemento 
nums.pop() #remove o 11 
# Revomer um elemento especifico pela posição
nums.pop(2) # Remover o numero na posição 2 da lista
#Remover um elemento pelo nome/valor dele 
nums.remove(91) # Remove 91
#copia da lista (em que as listas não ficam ligadas)
nums2 = nums.copy()