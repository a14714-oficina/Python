import random, os, getpass

# Variáveis
palavras = [
    "amarelo", "bicicleta", "computador", "janela", "montanha",
    "escola", "telefone", "planeta", "girassol", "biblioteca",
    "viagem", "amizade", "estrada", "floresta", "mercado",
    "pintura", "chaveiro", "travesseiro", "maratona", "teclado",
    "relogio", "aventura", "camiseta", "foguete", "baralho",
    "diamante", "churrasco", "desenho", "formiga", "castelo",
    "espelho", "morango", "telefone", "banheiro", "guitarra",
    "notebook", "bandeira", "jornal", "torneira", "alfinete",
    "paciente", "carteira", "professor", "cozinhar", "cordeiro",
    "geladeira", "tesoura", "fantasia", "pintor", "estrela",
    "trabalho", "violento", "museu", "carrossel", "helicoptero",
    "cimento", "pescador", "armario", "borboleta", "escada",
    "cimento", "oceano", "escritor", "dragao", "formato",
    "lenhador", "planicie", "tartaruga", "goleiro", "ventania",
    "cachorro", "flamingo", "dinossauro", "abacate", "camisola",
    "conjunto", "cerebro", "gramado", "sorvete", "bateria",
    "parque", "colher", "corda", "fechadura", "computar",
    "horizonte", "serenata", "diagrama", "tempestade", "amendoim",
    "piramide", "luminaria", "travesseu", "abacaxi", "foguista",
    "panqueca", "celebrar", "pintinho", "triangulo", "dentista",
    "pastel", "esquilo", "aquarela", "esmeralda", "lagosta"
]
palavra_secreta = random.choice(palavras)
tamanho = len(palavra_secreta)
minha_palavra = ['-' for _ in range(tamanho)]
print(palavra_secreta , tamanho, minha_palavra)
letras_erradas = []
forca = ['inteiro', 'cabeça','corpo','braço esquerdo','braço direito','pé esquerdo']
erros = 0 

# Começa o jogo
while erros < 6:
    # Ecrã
    for c in minha_palavra:
        print(f"{c} ", end="") #Escreve o elem, dá um espaço e mantém linha
    print()
    print("Letras: ", end="")
    for letra in letras_erradas:
        print(f"{letra} ", end="")
    print()
    print(f"Forca: {forca[erros]}")
    letra = input("Digite uma letra: ")
    letra = letra.lower()
    # Será que a letra pertence a palavra secreta?
    if letra not in palavra_secreta:
        erros = erros + 1
        letras_erradas.append(letra)
        os.system("cls" if os.name == "nt" else "clear")
        continue
    else:
        pos = 0
        for pos, c in enumerate(palavra_secreta):
            if c == letra:
                minha_palavra[pos] = c
        if minha_palavra == list(palavra_secreta):
            break
        os.system("cls" if os.name == "nt" else "clear")
# Terminou o While
if erros >= 6:
    print(f"Enforcado. A palavra secreta era {palavra_secreta}")
else:
    print("Parabéns, Acertou na palavra secreta!")
