# santiago = ["Santiago", "12-10-2007",72,1.67]
santiago = {'nome': 'Santiago',
'data_nasc': '12-10-2007',
'peso': 72,
'altura': 1.67}
'hobbies'['Passear',' Jogar','Ver TV']

# Par chave: valor
print(santiago['nome'])

# Imprimir as chaves
for chave in santiago.keys():
    print(chave)
# Imprimir só os valores
for valor in santiago.values():
    print(valor)
# Imprimir chave e valor
for chave, valor in santiago.items():
    print(f"{chave} - {valor}")
    
print(santiago)
print(santiago['hobbies'][1])
santiago['hobbies'].append("Aprender a cozinhar")
print(santiago)
      
