tarefas= []
# 1. Adicionar Tarefa
tarefas.append("Comprar pão")
print(f"{tarefas}")

# 2. Adicionar Múltiplas Tarefas
tarefas.extend(["Estudar Python", "Jogar"])
print(f" {tarefas}")

# 3. Inserir Tarefa em Posição Específica
tarefas.insert(1, "Comer")
print(f"{tarefas}")

# 4. Remover Tarefa por Nome
tarefas.remove("Comprar pão")
print(f"{tarefas}")

#5. Remover Última Tarefa ou por Índice
tarefas.pop(2)
print(f"{tarefas}")
#7. Contar Ocorrências da tarefa
x = tarefas.count("Jogar")
print(f"{x}")

# 8. Encontrar Índice de tarefa
indice = tarefas.index("Comer")
print(indice)

#9. Ordenar tarefas
tarefas.sort()
print(f"{tarefas}")

#10. Inverter ordem
tarefas.reverse()
print(f"{tarefas}")

#11. Copiar Listas de tarefas
novas_tarefas = tarefas.copy()
 

#6. Remover
tarefas.clear()
print(f"{tarefas}")

